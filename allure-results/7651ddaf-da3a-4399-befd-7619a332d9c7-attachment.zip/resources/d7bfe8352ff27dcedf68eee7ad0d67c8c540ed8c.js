/* TTACart - shared client state + page bootstraps.
   Pure vanilla JS. State persisted in localStorage. */
(function () {
  "use strict";

  // ---------- Data ----------
  var PRODUCTS = [
    {
      id: "tta-practice-backpack",
      name: "TTA Practice Backpack",
      desc: "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.",
      price: 29.99,
      img: "backpack"
    },
    {
      id: "tta-bike-light",
      name: "TTA Bike Light",
      desc: "A red light isn't the desired state in testing but it sure helps when riding your bike at night. Water-resistant with 3 lighting modes, 1 AAA battery included.",
      price: 9.99,
      img: "bike-light"
    },
    {
      id: "tta-bolt-tshirt",
      name: "TTA Bolt T-Shirt",
      desc: "Get your testing superhero on with the TTA bolt T-shirt. From American Apparel, 100% ringspun combed cotton, heather gray with red bolt.",
      price: 15.99,
      img: "bolt-tshirt"
    },
    {
      id: "tta-fleece-jacket",
      name: "TTA Fleece Jacket",
      desc: "It's not every day that you come across a midweight quarter-zip fleece jacket capable of handling everything from a relaxing day outdoors to a busy day at the office.",
      price: 49.99,
      img: "fleece"
    },
    {
      id: "tta-junior-tester-onesie",
      name: "TTA Junior Tester Onesie",
      desc: "Rib snap infant onesie for the junior automation engineer in development. Reinforced 3-snap bottom closure, two-needle hemmed sleeved and bottom won't unravel.",
      price: 7.99,
      img: "onesie"
    },
    {
      id: "test-allthethings-tshirt-red",
      name: "Test.allTheThings() T-Shirt (Red)",
      desc: "This classic TTA t-shirt is perfect to wear when cozying up to your keyboard to automate a few tests. Super-soft and comfy ringspun combed cotton.",
      price: 15.99,
      img: "redshirt"
    }
  ];

  var USERS = {
    standard_user: { ok: true },
    locked_out_user: { ok: false, error: "Epic sadface: Sorry, this user has been locked out." },
    problem_user: { ok: true, traits: ["problem"] },
    performance_glitch_user: { ok: true, traits: ["glitch"] },
    error_user: { ok: true, traits: ["error"] },
    visual_user: { ok: true, traits: ["visual"] }
  };
  var PASSWORD = "tta_secret";

  // ---------- State ----------
  var K = {
    user: "tta-cart-user",
    items: "tta-cart-items",
    sort: "tta-cart-sort",
    checkout: "tta-cart-checkout-info"
  };

  function lsGet(k, fallback) {
    try {
      var v = window.localStorage.getItem(k);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) { return fallback; }
  }
  function lsSet(k, v) {
    try { window.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  }
  function lsRm(k) {
    try { window.localStorage.removeItem(k); } catch (e) {}
  }

  function getUser() { return lsGet(K.user, null); }
  function getTraits() {
    var u = getUser();
    if (!u || !USERS[u]) return [];
    return USERS[u].traits || [];
  }
  function getCart() { return lsGet(K.items, []); }
  function setCart(arr) { lsSet(K.items, arr); }
  function getSort() { return lsGet(K.sort, "az"); }
  function setSort(s) { lsSet(K.sort, s); }
  function getCheckout() { return lsGet(K.checkout, {}); }
  function setCheckout(obj) { lsSet(K.checkout, obj); }
  function resetAll() { lsRm(K.items); lsRm(K.sort); lsRm(K.checkout); }

  function requireAuth() {
    if (!getUser()) { window.location.href = "./index.html"; return false; }
    return true;
  }

  // ---------- Product images (inline SVG factories) ----------
  function svgBackpack() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<rect x="30" y="30" width="60" height="70" rx="10" fill="#181717"/>' +
      '<rect x="38" y="38" width="44" height="40" rx="6" fill="#2a2a2a"/>' +
      '<path d="M40 30 Q40 18 60 18 Q80 18 80 30" stroke="#181717" stroke-width="6" fill="none"/>' +
      '<rect x="52" y="86" width="16" height="10" rx="2" fill="#10b981"/>' +
      '</svg>';
  }
  function svgBikeLight() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<rect x="20" y="40" width="56" height="40" rx="8" fill="#1f2937"/>' +
      '<circle cx="48" cy="60" r="18" fill="#fbbf24"/>' +
      '<circle cx="48" cy="60" r="10" fill="#fde68a"/>' +
      '<rect x="76" y="50" width="20" height="20" rx="4" fill="#374151"/>' +
      '<rect x="96" y="55" width="6" height="10" fill="#9ca3af"/>' +
      '</svg>';
  }
  function svgBoltShirt() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M20 30 L40 20 L80 20 L100 30 L92 50 L80 44 L80 100 L40 100 L40 44 L28 50 Z" fill="#374151"/>' +
      '<path d="M58 38 L52 64 L64 64 L58 88 L70 56 L60 56 L66 38 Z" fill="#e11d48"/>' +
      '</svg>';
  }
  function svgFleece() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M24 28 L40 18 L80 18 L96 28 L100 56 L88 56 L88 102 L32 102 L32 56 L20 56 Z" fill="#94a3b8"/>' +
      '<rect x="56" y="20" width="8" height="76" fill="#475569"/>' +
      '<rect x="56" y="20" width="8" height="6" fill="#cbd5e1"/>' +
      '<path d="M24 28 L40 18 L40 56 L24 56 Z" fill="#1f2937"/>' +
      '<path d="M96 28 L80 18 L80 56 L96 56 Z" fill="#1f2937"/>' +
      '</svg>';
  }
  function svgOnesie() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M30 28 L46 22 L74 22 L90 28 L92 48 L78 50 L78 90 L42 90 L42 50 L28 48 Z" fill="#fff" stroke="#d4d4d4" stroke-width="2"/>' +
      '<circle cx="58" cy="80" r="2" fill="#10b981"/>' +
      '<circle cx="66" cy="80" r="2" fill="#10b981"/>' +
      '<text x="60" y="58" text-anchor="middle" font-family="JetBrains Mono, monospace" font-size="9" fill="#10b981" font-weight="700">JR</text>' +
      '</svg>';
  }
  function svgRedShirt() {
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
      '<path d="M20 30 L40 20 L80 20 L100 30 L92 50 L80 44 L80 100 L40 100 L40 44 L28 50 Z" fill="#dc2626"/>' +
      '<text x="60" y="68" text-anchor="middle" font-family="JetBrains Mono, monospace" font-size="9" fill="#fff" font-weight="700">test.</text>' +
      '<text x="60" y="80" text-anchor="middle" font-family="JetBrains Mono, monospace" font-size="9" fill="#fff" font-weight="700">all()</text>' +
      '</svg>';
  }
  var IMG = {
    "backpack": svgBackpack,
    "bike-light": svgBikeLight,
    "bolt-tshirt": svgBoltShirt,
    "fleece": svgFleece,
    "onesie": svgOnesie,
    "redshirt": svgRedShirt
  };
  function productImg(slug) {
    var f = IMG[slug];
    return f ? f() : "";
  }
  function productImgWithProblem(slug) {
    // problem_user: swap to wrong image (next in list).
    if (getTraits().indexOf("problem") === -1) return productImg(slug);
    var keys = Object.keys(IMG);
    var idx = keys.indexOf(slug);
    var swap = keys[(idx + 1) % keys.length];
    return productImg(swap);
  }

  // ---------- Shared shell helpers ----------
  function renderTopbar(opts) {
    opts = opts || {};
    var menuBtn = opts.hideMenu ? "" :
      '<button type="button" id="react-burger-menu-btn" class="menu-btn" data-test="open-menu" aria-label="Open menu">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>' +
      '</button>';
    var cartCount = getCart().length;
    var badge = cartCount > 0 ? '<span class="cart-badge" data-test="shopping-cart-badge">' + cartCount + '</span>' : "";
    var cartLink = opts.hideCart ? "" :
      '<a class="cart-btn" id="shopping_cart_container" href="./cart.html" data-test="shopping-cart-link" aria-label="Shopping cart">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1.5"/><circle cx="18" cy="21" r="1.5"/><path d="M3 3h2l2.4 12.4a2 2 0 0 0 2 1.6h8.7a2 2 0 0 0 2-1.6L22 8H6"/></svg>' +
      badge +
      '</a>';
    return '<header class="tta-topbar" data-test="primary-header">' +
      menuBtn +
      '<span class="tta-brand-title">TTACart</span>' +
      cartLink +
      '</header>';
  }

  function renderSideMenu() {
    return '<div class="side-menu-backdrop" id="menuBackdrop"></div>' +
      '<aside class="side-menu" id="sideMenu" data-test="side-menu">' +
      '<button type="button" class="close-menu" id="react-burger-cross-btn" data-test="close-menu" aria-label="Close menu">×</button>' +
      '<a id="inventory_sidebar_link" data-test="inventory-sidebar-link" href="./inventory.html">All Items</a>' +
      '<a id="about_sidebar_link" data-test="about-sidebar-link" href="https://app.thetestingacademy.com/" rel="noopener">About</a>' +
      '<a id="logout_sidebar_link" data-test="logout-sidebar-link" href="#" data-action="logout">Logout</a>' +
      '<a id="reset_sidebar_link" data-test="reset-sidebar-link" href="#" data-action="reset">Reset App State</a>' +
      '</aside>';
  }

  function renderFooter() {
    return '<footer class="tta-footer" data-test="footer">' +
      '<div class="socials">' +
        '<a href="https://twitter.com/TheTestingAcad" target="_blank" rel="noopener" data-test="social-twitter" aria-label="Twitter">' +
          '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 5.8c-.7.3-1.5.5-2.3.6.8-.5 1.5-1.3 1.8-2.2-.8.5-1.7.8-2.6 1-1.5-1.6-4-1.7-5.6-.2-1 1-1.5 2.4-1.2 3.8C8.8 8.7 5.8 7.1 3.8 4.6 2.5 7 3.2 9.9 5.5 11.3c-.6 0-1.3-.2-1.9-.5 0 2.4 1.7 4.5 4 5-.6.2-1.3.2-1.9.1.5 1.7 2.1 2.9 4 3-2.3 1.8-5.4 2.4-8.1 1.5 2.5 1.6 5.4 2.5 8.4 2.5 9.6 0 14.9-8 14.6-15.2.6-.4 1.2-1 1.7-1.7z"/></svg>' +
        '</a>' +
        '<a href="https://facebook.com/" target="_blank" rel="noopener" data-test="social-facebook" aria-label="Facebook">' +
          '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12c0-5.5-4.5-10-10-10S2 6.5 2 12c0 5 3.7 9.1 8.4 9.9v-7H8v-2.9h2.4V9.8c0-2.4 1.4-3.7 3.6-3.7 1 0 2.1.2 2.1.2v2.3h-1.2c-1.2 0-1.5.7-1.5 1.5V12h2.6l-.4 2.9h-2.2V22c4.7-.8 8.4-4.9 8.4-9.9z"/></svg>' +
        '</a>' +
        '<a href="https://linkedin.com/" target="_blank" rel="noopener" data-test="social-linkedin" aria-label="LinkedIn">' +
          '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM3 9h4v12H3V9zm7 0h3.8v1.7h.1c.5-1 1.8-2 3.7-2 4 0 4.7 2.6 4.7 6V21h-4v-5.5c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9V21h-4V9z"/></svg>' +
        '</a>' +
      '</div>' +
      '<span data-test="footer-copy">(c) 2026 TTACart - The Testing Academy. All Rights Reserved. ' +
      '<a href="https://app.thetestingacademy.com/" target="_blank" rel="noopener">Terms of Service</a> | ' +
      '<a href="https://app.thetestingacademy.com/" target="_blank" rel="noopener">Privacy Policy</a>' +
      '</span>' +
      '</footer>';
  }

  function bindMenu() {
    var open = document.getElementById("react-burger-menu-btn");
    var close = document.getElementById("react-burger-cross-btn");
    var menu = document.getElementById("sideMenu");
    var bd = document.getElementById("menuBackdrop");
    function show() { if (menu) menu.classList.add("is-open"); if (bd) bd.classList.add("is-open"); }
    function hide() { if (menu) menu.classList.remove("is-open"); if (bd) bd.classList.remove("is-open"); }
    if (open) open.addEventListener("click", show);
    if (close) close.addEventListener("click", hide);
    if (bd) bd.addEventListener("click", hide);

    document.querySelectorAll('[data-action="logout"]').forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault();
        lsRm(K.user);
        window.location.href = "./index.html";
      });
    });
    document.querySelectorAll('[data-action="reset"]').forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault();
        resetAll();
        hide();
        if (typeof window.ttacartRefresh === "function") {
          window.ttacartRefresh();
          updateBadge();
        } else {
          window.location.reload();
        }
      });
    });
  }

  function applyUserTraits() {
    var traits = getTraits();
    document.body.classList.remove("problem-user", "visual-user", "error-user", "glitch-user");
    traits.forEach(function (t) { document.body.classList.add(t + "-user"); });
  }

  // ---------- Login ----------
  function bootLogin() {
    var form = document.getElementById("login-form");
    if (!form) return;
    var err = document.getElementById("login-error");
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      err.classList.remove("is-visible");
      err.textContent = "";
      var u = document.getElementById("user-name").value.trim();
      var p = document.getElementById("password").value;
      if (!u) { err.textContent = "Epic sadface: Username is required"; err.classList.add("is-visible"); return; }
      if (!p) { err.textContent = "Epic sadface: Password is required"; err.classList.add("is-visible"); return; }
      if (!USERS[u] || p !== PASSWORD) {
        err.textContent = "Epic sadface: Username and password do not match any user in this service";
        err.classList.add("is-visible");
        return;
      }
      var userDef = USERS[u];
      if (userDef.ok === false) {
        err.textContent = userDef.error;
        err.classList.add("is-visible");
        return;
      }
      lsSet(K.user, u);
      var traits = userDef.traits || [];
      var delay = traits.indexOf("glitch") !== -1 ? 4000 : 0;
      var btn = document.querySelector("#login-button");
      if (btn && delay) { btn.disabled = true; btn.textContent = "Logging in..."; }
      setTimeout(function () { window.location.href = "./inventory.html"; }, delay);
    });
  }

  // ---------- Inventory ----------
  function sortProducts(list, key) {
    var arr = list.slice();
    if (getTraits().indexOf("problem") !== -1) return arr; // problem_user ignores sort
    if (key === "az") arr.sort(function (a, b) { return a.name.localeCompare(b.name); });
    else if (key === "za") arr.sort(function (a, b) { return b.name.localeCompare(a.name); });
    else if (key === "lohi") arr.sort(function (a, b) { return a.price - b.price; });
    else if (key === "hilo") arr.sort(function (a, b) { return b.price - a.price; });
    return arr;
  }

  function bootInventory() {
    if (!requireAuth()) return;
    var grid = document.getElementById("inventory-grid");
    if (!grid) return;
    var sortSel = document.getElementById("product-sort-container");
    sortSel.value = getSort();
    sortSel.addEventListener("change", function () {
      setSort(sortSel.value);
      renderGrid();
    });

    function renderGrid() {
      var cart = getCart();
      var key = getSort();
      var list = sortProducts(PRODUCTS, key);
      grid.innerHTML = list.map(function (p) {
        var inCart = cart.indexOf(p.id) !== -1;
        var btnClass = inCart ? "item-btn is-remove" : "item-btn";
        var btnText = inCart ? "Remove" : "Add to cart";
        var btnTest = inCart ? "remove-" + p.id : "add-to-cart-" + p.id;
        return '<article class="inventory-item" data-test="inventory-item">' +
          '<a class="item-img" href="./inventory-item.html?id=' + p.id + '" data-test="item-img-link">' + productImgWithProblem(p.img) + '</a>' +
          '<div class="item-body">' +
            '<div class="item-name" data-test="inventory-item-name"><a href="./inventory-item.html?id=' + p.id + '" data-test="item-' + p.id + '-title-link">' + p.name + '</a></div>' +
            '<div class="item-desc" data-test="inventory-item-desc">' + p.desc + '</div>' +
            '<div class="item-foot">' +
              '<div class="item-price" data-test="inventory-item-price">$' + p.price.toFixed(2) + '</div>' +
              '<button type="button" class="' + btnClass + '" data-test="' + btnTest + '" data-product="' + p.id + '">' + btnText + '</button>' +
            '</div>' +
          '</div>' +
          '</article>';
      }).join("");
      grid.querySelectorAll('[data-product]').forEach(function (btn) {
        btn.addEventListener("click", function () {
          var pid = btn.getAttribute("data-product");
          if (getTraits().indexOf("error") !== -1 && Math.random() < 0.3) return; // error_user random no-op
          var c = getCart();
          var i = c.indexOf(pid);
          if (i === -1) c.push(pid); else c.splice(i, 1);
          setCart(c);
          renderGrid();
          updateBadge();
        });
      });
    }
    window.ttacartRefresh = renderGrid;
    renderGrid();
  }

  function updateBadge() {
    var c = getCart().length;
    var el = document.querySelector('[data-test="shopping-cart-badge"]');
    var parent = document.querySelector('[data-test="shopping-cart-link"]');
    if (!parent) return;
    if (c > 0) {
      if (el) { el.textContent = String(c); }
      else { parent.insertAdjacentHTML("beforeend", '<span class="cart-badge" data-test="shopping-cart-badge">' + c + '</span>'); }
    } else {
      if (el) el.remove();
    }
  }

  // ---------- Inventory item detail ----------
  function bootInventoryItem() {
    if (!requireAuth()) return;
    var wrap = document.getElementById("inventory-detail");
    if (!wrap) return;
    var params = new URLSearchParams(window.location.search);
    var id = params.get("id");
    var p = PRODUCTS.find(function (x) { return x.id === id; });
    if (!p) {
      wrap.innerHTML =
        '<p data-test="not-found" style="padding: 22px; font-family: var(--mono);">Product not found.</p>' +
        '<a class="btn-continue" href="./inventory.html" data-test="back-to-products">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>' +
        ' Back to products</a>';
      return;
    }
    // keep tab title meaningful for screen-recordings + bookmarks
    document.title = "TTACart - " + p.name;

    function render() {
      var cart = getCart();
      var inCart = cart.indexOf(p.id) !== -1;
      var btnClass = inCart ? "item-btn is-remove" : "item-btn";
      var btnText = inCart ? "Remove" : "Add to cart";
      var btnTest = inCart ? "remove" : "add-to-cart";
      wrap.innerHTML =
        '<button type="button" class="back-btn" data-test="back-to-products" onclick="history.back()">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M19 12H5M12 19l-7-7 7-7"/></svg> Back' +
        '</button>' +
        '<div class="detail-row" data-test="inventory-container">' +
          '<div class="item-img">' + productImgWithProblem(p.img) + '</div>' +
          '<div class="detail-body">' +
            '<h2 data-test="inventory-item-name">' + p.name + '</h2>' +
            '<p data-test="inventory-item-desc">' + p.desc + '</p>' +
            '<div class="detail-foot">' +
              '<span class="item-price" data-test="inventory-item-price">$' + p.price.toFixed(2) + '</span>' +
              '<button type="button" class="' + btnClass + '" data-test="' + btnTest + '" id="add-to-cart">' + btnText + '</button>' +
            '</div>' +
          '</div>' +
        '</div>';
      wrap.querySelector("#add-to-cart").addEventListener("click", function () {
        var c = getCart();
        var i = c.indexOf(p.id);
        if (i === -1) c.push(p.id); else c.splice(i, 1);
        setCart(c);
        render();
        updateBadge();
      });
    }
    window.ttacartRefresh = render;
    render();
  }

  // ---------- Cart ----------
  function bootCart() {
    if (!requireAuth()) return;
    var wrap = document.getElementById("cart-contents-container");
    if (!wrap) return;
    function render() {
      var c = getCart();
      var items = c.map(function (id) { return PRODUCTS.find(function (p) { return p.id === id; }); }).filter(Boolean);
      var rows = items.map(function (p) {
        return '<div class="cart-row" data-test="inventory-item" data-product="' + p.id + '">' +
          '<div class="qty"><span class="cart-quantity" data-test="item-quantity">1</span></div>' +
          '<div class="cart-desc-block">' +
            '<a class="cart-name" data-test="inventory-item-name" href="./inventory-item.html?id=' + p.id + '">' + p.name + '</a>' +
            '<div class="cart-desc" data-test="inventory-item-desc">' + p.desc + '</div>' +
            '<div class="cart-price" data-test="inventory-item-price">$' + p.price.toFixed(2) + '</div>' +
          '</div>' +
          '<div class="remove-cell"><button type="button" class="btn-remove" data-test="remove-' + p.id + '" data-product="' + p.id + '">Remove</button></div>' +
          '</div>';
      }).join("");
      wrap.innerHTML =
        '<div class="cart-row-head" data-test="cart-list">' +
          '<div>QTY</div><div>Description</div><div></div>' +
        '</div>' +
        (rows || '<p style="padding: 22px; font-family: var(--mono);" data-test="cart-empty">Your cart is empty.</p>') +
        '<div class="cart-actions">' +
          '<a class="btn-continue" href="./inventory.html" data-test="continue-shopping">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>' +
          ' Continue Shopping</a>' +
          '<a class="btn-primary" href="./checkout-step-one.html" data-test="checkout">Checkout</a>' +
        '</div>';
      wrap.querySelectorAll('.btn-remove').forEach(function (btn) {
        btn.addEventListener("click", function () {
          var pid = btn.getAttribute("data-product");
          var arr = getCart().filter(function (x) { return x !== pid; });
          setCart(arr);
          render();
          updateBadge();
        });
      });
    }
    window.ttacartRefresh = render;
    render();
  }

  // ---------- Checkout step 1 ----------
  function bootCheckout1() {
    if (!requireAuth()) return;
    var form = document.getElementById("checkout-form");
    if (!form) return;
    var saved = getCheckout();
    if (saved.firstName) document.getElementById("first-name").value = saved.firstName;
    if (saved.lastName)  document.getElementById("last-name").value  = saved.lastName;
    if (saved.postal)    document.getElementById("postal-code").value = saved.postal;

    var err = document.getElementById("checkout-error");
    var problemTriggered = false;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      err.classList.remove("is-visible");
      err.textContent = "";
      var fn = document.getElementById("first-name").value.trim();
      var ln = document.getElementById("last-name").value.trim();
      var zip = document.getElementById("postal-code").value.trim();
      if (!fn) { err.textContent = "Error: First Name is required"; err.classList.add("is-visible"); return; }
      if (!ln) { err.textContent = "Error: Last Name is required"; err.classList.add("is-visible"); return; }
      if (!zip) { err.textContent = "Error: Postal Code is required"; err.classList.add("is-visible"); return; }

      // problem_user quirk: on first valid submit, clear firstName + show error.
      // Subsequent submits succeed so the user can complete the flow.
      if (!problemTriggered && getTraits().indexOf("problem") !== -1) {
        problemTriggered = true;
        document.getElementById("first-name").value = "";
        err.textContent = "Error: First Name is required";
        err.classList.add("is-visible");
        return;
      }
      setCheckout({ firstName: fn, lastName: ln, postal: zip });
      window.location.href = "./checkout-step-two.html";
    });
  }

  // ---------- Checkout step 2 (overview) ----------
  function bootCheckout2() {
    if (!requireAuth()) return;
    var wrap = document.getElementById("checkout-summary");
    if (!wrap) return;
    var c = getCart();
    var items = c.map(function (id) { return PRODUCTS.find(function (p) { return p.id === id; }); }).filter(Boolean);
    var subtotal = items.reduce(function (s, p) { return s + p.price; }, 0);
    var tax = Math.round(subtotal * 0.08 * 100) / 100;
    var total = Math.round((subtotal + tax) * 100) / 100;

    var rows = items.map(function (p) {
      return '<div class="cart-row" data-test="inventory-item" data-product="' + p.id + '">' +
        '<div class="qty"><span class="cart-quantity" data-test="item-quantity">1</span></div>' +
        '<div class="cart-desc-block">' +
          '<div class="cart-name" data-test="inventory-item-name">' + p.name + '</div>' +
          '<div class="cart-desc" data-test="inventory-item-desc">' + p.desc + '</div>' +
          '<div class="cart-price" data-test="inventory-item-price">$' + p.price.toFixed(2) + '</div>' +
        '</div>' +
        '<div></div>' +
        '</div>';
    }).join("");

    wrap.innerHTML =
      '<div class="cart-row-head" data-test="cart-list"><div>QTY</div><div>Description</div><div></div></div>' +
      rows +
      '<div class="summary-block">' +
        '<div><h4>Payment Information:</h4><div data-test="payment-info-value">TTACard #31337</div></div>' +
        '<div><h4>Shipping Information:</h4><div data-test="shipping-info-value">Free TTA Express Delivery!</div></div>' +
        '<div><h4>Price Total</h4>' +
          '<div class="summary-totals">' +
            '<div class="row" data-test="subtotal-label">Item total: $' + subtotal.toFixed(2) + '</div>' +
            '<div class="row" data-test="tax-label">Tax: $' + tax.toFixed(2) + '</div>' +
            '<div class="row total-row" data-test="total-label">Total: $' + total.toFixed(2) + '</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="form-actions">' +
        '<a class="btn-continue" href="./cart.html" data-test="cancel">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14"><path d="M19 12H5M12 19l-7-7 7-7"/></svg> Cancel</a>' +
        '<button type="button" class="btn-primary" data-test="finish" id="finish-btn">Finish</button>' +
      '</div>';

    document.getElementById("finish-btn").addEventListener("click", function () {
      setCart([]);  // empty cart after order
      window.location.href = "./checkout-complete.html";
    });
  }

  // ---------- Boot dispatch ----------
  function init() {
    // inject side menu + footer if placeholders exist
    var hostSide = document.getElementById("menu-host");
    if (hostSide) hostSide.innerHTML = renderSideMenu();
    var hostFoot = document.getElementById("footer-host");
    if (hostFoot) hostFoot.innerHTML = renderFooter();
    var hostTop = document.getElementById("topbar-host");
    if (hostTop) {
      var opts = JSON.parse(hostTop.getAttribute("data-opts") || "{}");
      hostTop.outerHTML = renderTopbar(opts);
    }
    bindMenu();
    applyUserTraits();

    var page = document.body.getAttribute("data-page");
    if (page === "login") bootLogin();
    else if (page === "inventory") bootInventory();
    else if (page === "inventory-item") bootInventoryItem();
    else if (page === "cart") bootCart();
    else if (page === "checkout-one") bootCheckout1();
    else if (page === "checkout-two") bootCheckout2();
    else if (page === "checkout-complete") { requireAuth(); }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Expose for debugging only
  window.TTACart = { PRODUCTS: PRODUCTS, USERS: USERS, getCart: getCart, getUser: getUser, resetAll: resetAll };
})();
